
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion } from "framer-motion";
import { initializeApp } from "firebase/app";
import {
  getFirestore,
  collection,
  addDoc,
  getDocs,
  query,
  serverTimestamp,
  orderBy
} from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyDiYlyx4kTjVnzlVbwC_P9U_e9AnRcPdyU",
  authDomain: "dynamis-name-wheel.firebaseapp.com",
  projectId: "dynamis-name-wheel",
  storageBucket: "dynamis-name-wheel.firebasestorage.app",
  messagingSenderId: "125827991923",
  appId: "1:125827991923:web:604c967929d98d8b109d06",
  measurementId: "G-M14EK1S4PN"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export default function MemorialWheel() {
  const [names, setNames] = useState([]);
  const [newName, setNewName] = useState("");
  const [selected, setSelected] = useState(null);
  const [lastSubmitted, setLastSubmitted] = useState(0);

  useEffect(() => {
    const fetchNames = async () => {
      const q = query(collection(db, "honoredNames"), orderBy("timestamp", "asc"));
      const querySnapshot = await getDocs(q);
      setNames(querySnapshot.docs.map(doc => doc.data().name));
    };
    fetchNames();
  }, []);

  const spinWheel = () => {
    const randomIndex = Math.floor(Math.random() * names.length);
    setSelected(names[randomIndex]);
  };

  const addName = async () => {
    const now = Date.now();
    if (now - lastSubmitted < 60000) return;
    const trimmed = newName.trim();
    if (!trimmed || names.includes(trimmed)) return;

    await addDoc(collection(db, "honoredNames"), {
      name: trimmed,
      timestamp: serverTimestamp(),
    });
    setNames([...names, trimmed]);
    setNewName("");
    setLastSubmitted(now);
  };

  return (
    <div className="p-4 max-w-xl mx-auto text-center">
      <h1 className="text-2xl font-bold mb-4">Memorial Day Wheel of Honor</h1>
      <div className="mb-4">
        <Input
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          placeholder="Add a name to honor"
          className="mb-2"
        />
        <Button onClick={addName}>Add Name</Button>
      </div>
      <div className="mb-4">
        <Button onClick={spinWheel}>Spin the Wheel</Button>
        {selected && (
          <motion.div
            className="mt-4 text-xl font-semibold text-blue-700"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            🎖 {selected}
          </motion.div>
        )}
      </div>
      <ul className="text-left mt-6 max-h-60 overflow-auto border rounded p-2">
        {names.map((name, idx) => (
          <li key={idx}>• {name}</li>
        ))}
      </ul>
    </div>
  );
}
