
import React from 'react';
import MemorialWheel from './components/MemorialWheel';

function App() {
  return <MemorialWheel />;
}

export default App;
